<?php

// 阿里云 Access Key Id
$AccessKeyId = 'LTAI5tFJact1y8YufScX8Drv';
   
// 阿里云 Access Key Secret
$AccessKeySecret = '2cvOIdO9d990sMOCicBTf0OXmyo2Ms';
   
// 短信签名
$sign = 'Nanstars博客';

// 短信模板CODE，如 SMS_123456789
$template = 'SMS_270335350';